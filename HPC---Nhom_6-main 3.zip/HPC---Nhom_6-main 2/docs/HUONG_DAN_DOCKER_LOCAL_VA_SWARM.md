# Hướng dẫn Docker Local và Docker Swarm

Tài liệu này tách hai chế độ chạy hệ thống:

- `docker-compose.local.yml`: dùng để demo và chạy trên máy cá nhân.
- `docker-compose.swarm.yml`: dùng cho triển khai Docker Swarm nhiều replica.

## 1. Chạy local trên máy cá nhân

Đứng ở thư mục gốc project:

```bash
cd HPC---Nhom_6-main
```

Chạy hệ thống:

```bash
docker compose -f docker-compose.local.yml up --build
```

Mở API qua Nginx:

```bash
open http://localhost/docs
```

Mở dashboard:

```bash
open http://localhost:8501
```

Dừng hệ thống:

```bash
docker compose -f docker-compose.local.yml down
```

## 2. Chạy test API

```bash
python3 tests/api_test.py --url http://localhost
```

Test thêm SHAP:

```bash
python3 tests/api_test.py --url http://localhost --include-explain
```

## 3. Chạy API benchmark

```bash
python3 benchmark/run_benchmark.py --url http://localhost --requests 200 --concurrency 10
python3 benchmark/run_benchmark.py --url http://localhost --requests 500 --concurrency 25
```

Mở báo cáo:

```bash
open benchmark/results/benchmark_report.html
```

## 4. Chạy Docker Swarm

Khởi tạo Swarm nếu chưa có:

```bash
docker swarm init
```

Build và push image trước khi deploy Swarm. Cần đổi `your-dockerhub-username` trong `docker-compose.swarm.yml` thành tên Docker Hub thật.

```bash
docker build -f docker/api.Dockerfile -t your-dockerhub-username/fraud-api:latest .
docker build -f docker/dashboard.Dockerfile -t your-dockerhub-username/fraud-dashboard:latest .
docker push your-dockerhub-username/fraud-api:latest
docker push your-dockerhub-username/fraud-dashboard:latest
```

Deploy stack:

```bash
docker stack deploy -c docker-compose.swarm.yml fraud-stack
```

Kiểm tra service:

```bash
docker stack services fraud-stack
docker service ls
```

Scale API:

```bash
docker service scale fraud-stack_api=3
```

Xem log:

```bash
docker service logs fraud-stack_api --tail 100
```

Gỡ stack:

```bash
docker stack rm fraud-stack
```

## 5. Lưu ý

- File local dùng `build` và `bridge network`, phù hợp demo trên một máy.
- File Swarm dùng `image`, `deploy`, `overlay network`, phù hợp triển khai nhiều replica.
- Nếu chạy local, ưu tiên dùng `docker-compose.local.yml` để tránh lỗi do `overlay` hoặc `configs` của Swarm.
