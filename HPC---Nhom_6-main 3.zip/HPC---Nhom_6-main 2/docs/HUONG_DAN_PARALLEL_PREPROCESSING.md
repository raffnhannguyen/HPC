# Hướng dẫn Parallel Preprocessing Benchmark

File `benchmark/parallel_preprocessing_benchmark.py` dùng để so sánh thời gian tiền xử lý dữ liệu giữa hai cách:

- Xử lý tuần tự: xử lý toàn bộ dữ liệu trong một tiến trình.
- Xử lý song song: chia dữ liệu thành nhiều chunk và xử lý đồng thời bằng nhiều worker CPU.

## Cách chạy cơ bản

Đứng ở thư mục gốc project:

```bash
python3 benchmark/parallel_preprocessing_benchmark.py --input data/processed/test.csv --sample-size 200000 --workers 4
```

Nếu muốn chạy toàn bộ file:

```bash
python3 benchmark/parallel_preprocessing_benchmark.py --input data/processed/test.csv --sample-size 0 --workers 4
```

Nếu có raw dataset PaySim, có thể chạy:

```bash
python3 benchmark/parallel_preprocessing_benchmark.py --input data/raw/PS_20174392719_1491204439457_log.csv --mode raw --sample-size 200000 --workers 4
```

## Output

Kết quả được lưu tại:

```text
benchmark/results/parallel_preprocessing_summary.json
benchmark/results/parallel_preprocessing_report.md
benchmark/results/parallel_preprocessing_sample.csv
```

## Ý nghĩa chỉ số

- `sequential_time_seconds`: thời gian xử lý tuần tự.
- `parallel_time_seconds`: thời gian xử lý song song.
- `speedup`: mức tăng tốc, tính bằng `sequential_time / parallel_time`.
- `efficiency_pct`: hiệu suất sử dụng worker, tính bằng `speedup / workers * 100`.

## Cách trình bày trong báo cáo

Có thể viết:

> Do dữ liệu giao dịch tài chính có kích thước lớn, nhóm bổ sung thực nghiệm xử lý song song ở bước tiền xử lý dữ liệu. Dữ liệu được chia thành nhiều chunk và xử lý đồng thời bằng nhiều worker CPU. Kết quả được so sánh với xử lý tuần tự thông qua thời gian chạy, speedup và efficiency. Thực nghiệm này cho thấy khả năng tận dụng tài nguyên CPU để tăng tốc một phần pipeline dữ liệu trong bài toán phát hiện gian lận.

Lưu ý: nếu file đầu vào là `data/processed/test.csv`, dữ liệu đã được preprocess trước đó, nên benchmark đo bước chuẩn bị feature theo chunk. Nếu dùng raw dataset, benchmark đo đầy đủ bước feature engineering.
