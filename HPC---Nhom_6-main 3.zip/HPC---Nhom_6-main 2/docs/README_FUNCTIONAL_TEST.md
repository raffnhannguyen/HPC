# Functional API Test Add-on

Copy `tests/api_test.py` into the root of your project, replacing the old `tests/api_test.py`.

## Run smoke + functional test

```bash
python3 tests/api_test.py --url http://localhost
```

## Run with SHAP explanation test

```bash
python3 tests/api_test.py --url http://localhost --include-explain
```

## Run with more random samples

```bash
python3 tests/api_test.py --url http://localhost --random-samples 50
```

## Run abnormal input tests

```bash
python3 tests/api_test.py --url http://localhost --include-abnormal
```

## Run full test

```bash
python3 tests/api_test.py --url http://localhost --include-explain --include-abnormal --random-samples 50
```
