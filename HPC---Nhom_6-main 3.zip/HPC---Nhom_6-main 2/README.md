# PHÁT HIỆN GIAN LẬN GIAO DỊCH TÀI CHÍNH VỚI MÔ HÌNH DEEP LEARNING TRIỂN KHAI TRÊN DOCKER

## 1. Giới thiệu

Đồ án xây dựng hệ thống phát hiện gian lận giao dịch tài chính dựa trên mô hình Deep Learning, trong đó mô hình chính là Feed Forward Neural Network (FFNN). Hệ thống được triển khai thành API bằng FastAPI, tích hợp dashboard Streamlit, giải thích dự đoán bằng SHAP và đóng gói bằng Docker.

Mục tiêu của đồ án không chỉ là huấn luyện mô hình, mà còn triển khai mô hình thành một dịch vụ có thể nhận request, dự đoán, giải thích kết quả và đánh giá hiệu năng khi có nhiều request đồng thời.

## 2. Kiến trúc hệ thống

Luồng hoạt động tổng quát:

```text
Người dùng / Test script / Benchmark
        ↓
Nginx reverse proxy
        ↓
FastAPI service
        ↓
Tiền xử lý input theo đúng feature schema
        ↓
FFNN model dự đoán xác suất gian lận
        ↓
API trả kết quả Fraud / Not Fraud
        ↓
Dashboard hiển thị kết quả và giải thích SHAP nếu cần
```

Các thành phần chính:

| Thành phần | Vai trò |
|---|---|
| FastAPI | Cung cấp endpoint `/predict`, `/explain`, `/health`, `/stats`, `/debug` |
| FFNN model | Mô hình chính để dự đoán gian lận |
| SHAP | Giải thích các feature ảnh hưởng đến dự đoán |
| Streamlit Dashboard | Giao diện nhập giao dịch và xem kết quả |
| Nginx | Reverse proxy đến API service |
| Docker Compose | Chạy hệ thống multi-container trên máy cá nhân |
| Docker Swarm | Triển khai nhiều replica API khi cần scale |
| Benchmark | Đo latency, throughput, P95, P99 và success rate |

## 3. Cấu trúc thư mục

```text
HPC---Nhom_6-main/
├── api/
│   ├── main.py
│   ├── requirements.txt
│   └── Test.txt
├── benchmark/
│   ├── run_benchmark.py
│   └── parallel_preprocessing_benchmark.py
├── dashboard/
│   ├── app.py
│   ├── Dockerfile
│   └── requirements.txt
├── data/
│   └── processed/
│       └── test.csv
├── docker/
│   ├── api.Dockerfile
│   └── dashboard.Dockerfile
├── docs/
│   └── HUONG_DAN_DOCKER_LOCAL_VA_SWARM.md
├── model/
│   └── saved_models/
├── nginx/
│   └── nginx.conf
├── notebook/
│   ├── preprocessing.ipynb
│   └── train_model.ipynb
├── tests/
│   └── api_test.py
├── xai/
│   ├── xai_analysis.py
│   └── results/
├── docker-compose.local.yml
├── docker-compose.swarm.yml
├── DOCKER_DEPLOY.md
└── README.md
```

## 4. Mô hình sử dụng

Mô hình chính trong API là FFNN, được lưu tại:

```text
model/saved_models/ffnn.h5
```

Các file đi kèm:

```text
scaler.pkl
feature_names.pkl
numeric_cols.pkl
binary_cols.pkl
ffnn_threshold.pkl
```

API sử dụng `feature_names.pkl` để đảm bảo input sau tiền xử lý có đúng thứ tự feature như lúc huấn luyện. `scaler.pkl` được dùng để chuẩn hóa các biến numeric, còn `ffnn_threshold.pkl` là ngưỡng phân loại Fraud / Not Fraud.

## 5. Chuẩn bị dữ liệu

API sử dụng file:

```text
data/processed/test.csv
```

File này cần là dữ liệu đã preprocess, có các feature đúng schema và cột `isFraud`. File được dùng để tạo background data cho SHAP.

## 6. Chạy hệ thống local bằng Docker Compose

Đứng ở thư mục gốc project:

```bash
cd HPC---Nhom_6-main
```

Chạy local:

```bash
docker compose -f docker-compose.local.yml up --build
```

Mở API docs:

```bash
open http://localhost/docs
```

Mở dashboard:

```bash
open http://localhost:8501
```

Dừng hệ thống:

```bash
docker compose -f docker-compose.local.yml down
```

## 7. Chạy Docker Swarm

File Swarm là:

```text
docker-compose.swarm.yml
```

Trước khi deploy Swarm, cần build và push image lên Docker Hub hoặc registry nội bộ, sau đó đổi `your-dockerhub-username` trong file compose.

Khởi tạo Swarm:

```bash
docker swarm init
```

Deploy stack:

```bash
docker stack deploy -c docker-compose.swarm.yml fraud-stack
```

Scale API:

```bash
docker service scale fraud-stack_api=3
```

Kiểm tra service:

```bash
docker service ls
docker stack services fraud-stack
```

Gỡ stack:

```bash
docker stack rm fraud-stack
```

## 8. Test API

Chạy smoke test và functional test:

```bash
python3 tests/api_test.py --url http://localhost
```

Test thêm SHAP:

```bash
python3 tests/api_test.py --url http://localhost --include-explain
```

Test thêm dữ liệu bất thường:

```bash
python3 tests/api_test.py --url http://localhost --include-abnormal
```

Tăng số mẫu random hợp lệ:

```bash
python3 tests/api_test.py --url http://localhost --random-samples 50
```

## 9. API benchmark

Benchmark dùng để đánh giá hiệu năng endpoint `/predict` khi có nhiều request đồng thời.

Tải vừa:

```bash
python3 benchmark/run_benchmark.py --url http://localhost --requests 200 --concurrency 10
```

Tải cao:

```bash
python3 benchmark/run_benchmark.py --url http://localhost --requests 500 --concurrency 25
```

Benchmark với input ngẫu nhiên:

```bash
python3 benchmark/run_benchmark.py --url http://localhost --requests 500 --concurrency 25 --randomize-input
```

Kết quả được lưu tại:

```text
benchmark/results/
```

Các file kết quả:

```text
latency_results.csv
benchmark_summary.json
benchmark_report.md
benchmark_report.html
```

Mở báo cáo HTML:

```bash
open benchmark/results/benchmark_report.html
```

## 10. Parallel preprocessing benchmark

Chạy benchmark xử lý dữ liệu song song:

```bash
python3 benchmark/parallel_preprocessing_benchmark.py --input data/processed/test.csv --sample-size 200000 --workers 4
```

Chạy toàn bộ file:

```bash
python3 benchmark/parallel_preprocessing_benchmark.py --input data/processed/test.csv --sample-size 0 --workers 4
```

Các chỉ số quan trọng:

| Chỉ số | Ý nghĩa |
|---|---|
| Sequential time | Thời gian xử lý tuần tự |
| Parallel time | Thời gian xử lý song song |
| Speedup | Mức tăng tốc so với xử lý tuần tự |
| Efficiency | Mức tận dụng tài nguyên worker |

## 11. Ý nghĩa HPC trong đồ án

Yếu tố HPC được thể hiện ở hai tầng:

1. **Tầng triển khai service**: mô hình FFNN được đóng gói thành API, chạy trong Docker, có Nginx reverse proxy và có thể scale nhiều replica bằng Docker Swarm.
2. **Tầng đánh giá hiệu năng**: hệ thống được benchmark bằng nhiều request đồng thời, đo throughput, latency trung bình, P95, P99 và success rate. Ngoài ra, bước chuẩn bị dữ liệu được đánh giá bằng parallel preprocessing để so sánh xử lý tuần tự và xử lý song song.

## 12. Lỗi thường gặp

### API không thấy dataset

Kiểm tra:

```bash
ls -lh data/processed/test.csv
```

### API restart liên tục

Xem log:

```bash
docker compose -f docker-compose.local.yml logs api --tail=120
```

### Dashboard mở được nhưng predict lỗi

Kiểm tra biến môi trường `API_URL`. Khi dashboard chạy trong Docker, nên dùng:

```text
API_URL=http://nginx:80
```

### Benchmark lỗi 500

Chạy test API trước:

```bash
python3 tests/api_test.py --url http://localhost
```

Chỉ chạy benchmark sau khi test API đã PASS.
