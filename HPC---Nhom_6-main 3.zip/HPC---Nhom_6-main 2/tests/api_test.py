#!/usr/bin/env python3
"""
API functional test for the financial fraud detection system.

This script combines:
1. Smoke test: API reachability, health, debug, predict, stats, optional explain.
2. Functional test: representative transaction types: PAYMENT, TRANSFER, CASH_OUT, CASH_IN, DEBIT.
3. Randomized functional test: random but structurally valid transactions.
4. Abnormal input test: unusual/invalid inputs should not crash the API.

This file tests deployment/API behavior. It is not a replacement for model evaluation
on a labeled test set.
"""

from __future__ import annotations

import argparse
import random
import time
from typing import Any, Callable, Dict, List, Tuple

import requests

NORMAL_SAMPLE: Dict[str, Any] = {
    "step": 10,
    "type": "PAYMENT",
    "amount": 250.0,
    "oldbalanceOrg": 5000.0,
    "newbalanceOrig": 4750.0,
    "oldbalanceDest": 1000.0,
    "newbalanceDest": 1250.0,
    "nameDest": "M1979787155",
}

SUSPICIOUS_SAMPLE: Dict[str, Any] = {
    "step": 1,
    "type": "TRANSFER",
    "amount": 181.0,
    "oldbalanceOrg": 181.0,
    "newbalanceOrig": 0.0,
    "oldbalanceDest": 0.0,
    "newbalanceDest": 0.0,
    "nameDest": "C553264065",
}

FUNCTIONAL_SAMPLES: List[Tuple[str, Dict[str, Any]]] = [
    (
        "PAYMENT normal merchant transaction",
        {
            "step": 12,
            "type": "PAYMENT",
            "amount": 125.5,
            "oldbalanceOrg": 3000.0,
            "newbalanceOrig": 2874.5,
            "oldbalanceDest": 800.0,
            "newbalanceDest": 925.5,
            "nameDest": "M123456789",
        },
    ),
    (
        "TRANSFER suspicious balance emptied",
        {
            "step": 1,
            "type": "TRANSFER",
            "amount": 181.0,
            "oldbalanceOrg": 181.0,
            "newbalanceOrig": 0.0,
            "oldbalanceDest": 0.0,
            "newbalanceDest": 0.0,
            "nameDest": "C553264065",
        },
    ),
    (
        "CASH_OUT suspicious large cash out",
        {
            "step": 24,
            "type": "CASH_OUT",
            "amount": 50000.0,
            "oldbalanceOrg": 50000.0,
            "newbalanceOrig": 0.0,
            "oldbalanceDest": 1000.0,
            "newbalanceDest": 51000.0,
            "nameDest": "C985412001",
        },
    ),
    (
        "CASH_IN normal incoming transaction",
        {
            "step": 36,
            "type": "CASH_IN",
            "amount": 1200.0,
            "oldbalanceOrg": 2000.0,
            "newbalanceOrig": 3200.0,
            "oldbalanceDest": 6000.0,
            "newbalanceDest": 4800.0,
            "nameDest": "C177320981",
        },
    ),
    (
        "DEBIT small debit transaction",
        {
            "step": 48,
            "type": "DEBIT",
            "amount": 75.0,
            "oldbalanceOrg": 1000.0,
            "newbalanceOrig": 925.0,
            "oldbalanceDest": 250.0,
            "newbalanceDest": 325.0,
            "nameDest": "C871231900",
        },
    ),
]


def normalize_url(url: str) -> str:
    return url.rstrip("/")


def request_json(method: str, url: str, **kwargs: Any) -> Tuple[int, Dict[str, Any], float]:
    started = time.perf_counter()
    response = requests.request(method, url, timeout=60, **kwargs)
    latency_ms = (time.perf_counter() - started) * 1000
    try:
        body = response.json()
    except ValueError:
        body = {"raw_text": response.text}
    return response.status_code, body, latency_ms


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def run_test(name: str, func: Callable[[], None]) -> bool:
    print(f"[TEST] {name} ... ", end="", flush=True)
    try:
        func()
        print("PASS")
        return True
    except Exception as exc:
        print("FAIL")
        print(f"       {type(exc).__name__}: {exc}")
        return False


def validate_predict_response(body: Dict[str, Any]) -> None:
    check("prediction" in body, "Response must contain 'prediction'")
    check("fraud_probability" in body, "Response must contain 'fraud_probability'")
    prediction = body.get("prediction")
    probability = body.get("fraud_probability")
    check(prediction in [0, 1, "0", "1", False, True], f"Invalid prediction value: {prediction}")
    check(isinstance(probability, (int, float)), f"fraud_probability must be numeric, got {type(probability)}")
    check(0.0 <= float(probability) <= 1.0, f"fraud_probability must be in [0, 1], got {probability}")


def random_transaction() -> Dict[str, Any]:
    tx_type = random.choice(["PAYMENT", "TRANSFER", "CASH_OUT", "CASH_IN", "DEBIT"])
    amount = round(random.uniform(1.0, 100000.0), 2)
    old_orig = round(random.uniform(0.0, 150000.0), 2)

    if tx_type in ["TRANSFER", "CASH_OUT"] and random.random() < 0.35:
        old_orig = amount
        new_orig = 0.0
    elif tx_type == "CASH_IN":
        new_orig = old_orig + amount
    else:
        new_orig = max(0.0, old_orig - amount)

    old_dest = round(random.uniform(0.0, 150000.0), 2)
    if tx_type == "CASH_IN":
        new_dest = max(0.0, old_dest - amount)
    else:
        new_dest = old_dest + amount

    prefix = "M" if tx_type == "PAYMENT" and random.random() < 0.7 else "C"
    return {
        "step": random.randint(1, 744),
        "type": tx_type,
        "amount": amount,
        "oldbalanceOrg": old_orig,
        "newbalanceOrig": round(new_orig, 2),
        "oldbalanceDest": old_dest,
        "newbalanceDest": round(new_dest, 2),
        "nameDest": f"{prefix}{random.randint(100000000, 999999999)}",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Smoke + functional API test for fraud detection service.")
    parser.add_argument("--url", default="http://localhost", help="Base API URL, e.g. http://localhost or http://localhost:8000")
    parser.add_argument("--include-explain", action="store_true", help="Also test /explain endpoint. This can be slower because SHAP is expensive.")
    parser.add_argument("--random-samples", type=int, default=10, help="Number of random valid transactions to test.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducible random tests.")
    parser.add_argument("--include-abnormal", action="store_true", help="Also run abnormal input tests.")
    args = parser.parse_args()

    random.seed(args.seed)
    base_url = normalize_url(args.url)
    stats_before: Dict[str, Any] = {}

    def test_root() -> None:
        status, body, _ = request_json("GET", f"{base_url}/")
        check(status == 200, f"Expected status 200, got {status}. Response: {body}")

    def test_health() -> None:
        status, body, _ = request_json("GET", f"{base_url}/health")
        check(status == 200, f"Expected status 200, got {status}. Response: {body}")

    def test_debug() -> None:
        status, body, _ = request_json("GET", f"{base_url}/debug")
        check(status == 200, f"Expected status 200, got {status}. Response: {body}")
        check(any(key in body for key in ["feature_names", "n_features", "threshold", "model_path"]),
              f"/debug response does not contain expected model metadata. Response: {body}")

    def test_stats_before() -> None:
        nonlocal stats_before
        status, body, _ = request_json("GET", f"{base_url}/stats")
        check(status == 200, f"Expected status 200, got {status}. Response: {body}")
        stats_before = body

    def test_predict_normal() -> None:
        status, body, latency_ms = request_json("POST", f"{base_url}/predict", json=NORMAL_SAMPLE)
        check(status == 200, f"Expected status 200, got {status}. Response: {body}")
        validate_predict_response(body)
        print(f"\n       normal_prediction={body.get('prediction')} probability={float(body.get('fraud_probability')):.6f} latency_ms={latency_ms:.2f}", end="")

    def test_predict_suspicious() -> None:
        status, body, latency_ms = request_json("POST", f"{base_url}/predict", json=SUSPICIOUS_SAMPLE)
        check(status == 200, f"Expected status 200, got {status}. Response: {body}")
        validate_predict_response(body)
        print(f"\n       suspicious_prediction={body.get('prediction')} probability={float(body.get('fraud_probability')):.6f} latency_ms={latency_ms:.2f}", end="")

    def test_functional_samples() -> None:
        for case_name, payload in FUNCTIONAL_SAMPLES:
            status, body, latency_ms = request_json("POST", f"{base_url}/predict", json=payload)
            check(status == 200, f"{case_name}: expected status 200, got {status}. Response: {body}")
            validate_predict_response(body)
            print(f"\n       {case_name}: prediction={body.get('prediction')}, probability={float(body.get('fraud_probability')):.6f}, latency_ms={latency_ms:.2f}", end="")

    def test_random_samples() -> None:
        latencies: List[float] = []
        fraud_count = 0
        for i in range(args.random_samples):
            payload = random_transaction()
            status, body, latency_ms = request_json("POST", f"{base_url}/predict", json=payload)
            check(status == 200, f"Random sample {i + 1}: expected status 200, got {status}. Payload: {payload}. Response: {body}")
            validate_predict_response(body)
            latencies.append(latency_ms)
            if str(body.get("prediction")) in ["1", "True", "true"]:
                fraud_count += 1
        avg_latency = sum(latencies) / len(latencies) if latencies else 0.0
        print(f"\n       random_samples={args.random_samples}, fraud_predictions={fraud_count}, avg_latency_ms={avg_latency:.2f}", end="")

    def test_stats_after() -> None:
        status, body, _ = request_json("GET", f"{base_url}/stats")
        check(status == 200, f"Expected status 200, got {status}. Response: {body}")
        before = int(stats_before.get("total_predictions", 0) or 0)
        after = int(body.get("total_predictions", 0) or 0)
        # In multi-replica deployments, /predict and /stats may hit different containers.
        # Therefore, only require the counter not to go backwards.
        check(after >= before, f"total_predictions should not decrease. Before={before}, after={after}")

    def test_explain() -> None:
        status, body, latency_ms = request_json("POST", f"{base_url}/explain", json=SUSPICIOUS_SAMPLE)
        check(status == 200, f"Expected status 200, got {status}. Response: {body}")
        check(any(key in body for key in ["top_explanation", "shap_values", "explanation", "error"]),
              f"/explain response does not contain expected explanation fields. Response: {body}")
        print(f"\n       explain_latency_ms={latency_ms:.2f}", end="")

    def test_abnormal_inputs() -> None:
        abnormal_cases: List[Tuple[str, Dict[str, Any], List[int]]] = [
            ("negative amount", {
                "step": 1, "type": "TRANSFER", "amount": -100.0,
                "oldbalanceOrg": 1000.0, "newbalanceOrig": 1100.0,
                "oldbalanceDest": 500.0, "newbalanceDest": 400.0,
                "nameDest": "C100000001",
            }, [200, 400, 422]),
            ("unknown transaction type", {
                "step": 1, "type": "UNKNOWN_TYPE", "amount": 100.0,
                "oldbalanceOrg": 1000.0, "newbalanceOrig": 900.0,
                "oldbalanceDest": 500.0, "newbalanceDest": 600.0,
                "nameDest": "C100000002",
            }, [200, 400, 422]),
            ("missing required field", {
                "step": 1, "type": "TRANSFER", "amount": 100.0,
                "oldbalanceOrg": 1000.0, "newbalanceOrig": 900.0,
                "newbalanceDest": 600.0, "nameDest": "C100000003",
            }, [400, 422]),
        ]
        for case_name, payload, acceptable_statuses in abnormal_cases:
            status, body, _ = request_json("POST", f"{base_url}/predict", json=payload)
            check(status in acceptable_statuses,
                  f"{case_name}: expected one of {acceptable_statuses}, got {status}. Response: {body}")
            print(f"\n       {case_name}: status={status}", end="")

    tests: List[Tuple[str, Callable[[], None]]] = [
        ("GET /", test_root),
        ("GET /health", test_health),
        ("GET /debug", test_debug),
        ("GET /stats before", test_stats_before),
        ("POST /predict normal transaction", test_predict_normal),
        ("POST /predict suspicious transaction", test_predict_suspicious),
        ("POST /predict functional transaction types", test_functional_samples),
        ("POST /predict random valid transactions", test_random_samples),
        ("GET /stats after", test_stats_after),
    ]

    if args.include_explain:
        tests.append(("POST /explain", test_explain))
    if args.include_abnormal:
        tests.append(("POST /predict abnormal inputs", test_abnormal_inputs))

    passed = 0
    for name, func in tests:
        if run_test(name, func):
            passed += 1

    print(f"\nSummary: {passed}/{len(tests)} checks passed.")
    if passed == len(tests):
        print("API functional test completed successfully.")
        return 0

    print("Some checks failed. Review API logs with: docker compose logs api --tail=120")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
