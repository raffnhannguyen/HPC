# API Benchmark Report

## Configuration

| Metric | Value |
|---|---:|
| API URL | `http://localhost` |
| Endpoint | `/predict` |
| Started at | 2026-05-29 19:24:37 |
| Total requests | 500 |
| Concurrency | 25 |
| Timeout | 60.0 seconds |
| Randomize input | True |

## Results

| Metric | Value |
|---|---:|
| Successful requests | 500 |
| Failed requests | 0 |
| Success rate | 100.00% |
| Wall time | 10.0548 seconds |
| Throughput | 49.7274 requests/second |
| Average latency | 498.7620 ms |
| Minimum latency | 202.9927 ms |
| Maximum latency | 1034.3054 ms |
| P50 latency | 480.2489 ms |
| P95 latency | 703.5692 ms |
| P99 latency | 826.4655 ms |

## Interpretation

This benchmark evaluates the deployed model service under concurrent requests. Throughput shows how many prediction requests the system can process per second. Average latency shows the mean response time, while P95 and P99 latency describe tail latency under load. A high success rate and low failed request count indicate stable deployment behavior.
