# Parallel Preprocessing Benchmark Report

## Configuration

| Item | Value |
|---|---:|
| Input path | `data/processed/test.csv` |
| Detected mode | `processed` |
| Rows processed | 200,000 |
| Output columns | 16 |
| Workers | 4 |
| Chunks | 8 |
| Sample size | 200000 |

## Result

| Metric | Value |
|---|---:|
| Sequential time | 0.012456 seconds |
| Parallel time | 0.551474 seconds |
| Speedup | 0.0226x |
| Efficiency | 0.56% |

## Interpretation

Speedup is calculated as sequential time divided by parallel time. Efficiency is calculated as speedup divided by number of workers. If the input file is already processed, this benchmark measures parallel feature preparation. If the input file is raw PaySim-style data, this benchmark measures feature engineering and model-ready transformation.

A speedup greater than 1 indicates that parallel processing is faster than sequential processing. If speedup is less than 1, the overhead of multiprocessing is larger than the benefit for the tested data size. This can happen when the dataset is small or when the preprocessing operations are already highly optimized by pandas.
