#!/usr/bin/env python3
"""
API Benchmark for Fraud Detection Service

This script sends concurrent POST requests to the /predict endpoint and reports
latency, throughput, success rate, and percentile metrics. It is designed for
HPC deployment evaluation after the FastAPI model service has been deployed
with Docker, Nginx, or Docker Swarm.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import csv
import html
import json
import random
import statistics
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

import requests


BASE_TRANSACTION: Dict[str, Any] = {
    "step": 1,
    "type": "TRANSFER",
    "amount": 181.0,
    "oldbalanceOrg": 181.0,
    "newbalanceOrig": 0.0,
    "oldbalanceDest": 0.0,
    "newbalanceDest": 0.0,
    "nameDest": "C553264065",
}

TRANSACTION_TYPES = ["PAYMENT", "TRANSFER", "CASH_OUT", "CASH_IN", "DEBIT"]


def normalize_url(url: str) -> str:
    return url.rstrip("/")


def make_transaction(randomize: bool, rng: random.Random) -> Dict[str, Any]:
    """Create a valid transaction payload for the /predict endpoint."""
    if not randomize:
        return dict(BASE_TRANSACTION)

    tx_type = rng.choice(TRANSACTION_TYPES)
    amount = round(rng.uniform(1.0, 2_000_000.0), 2)
    old_org = round(rng.uniform(0.0, 3_000_000.0), 2)

    if tx_type in {"TRANSFER", "CASH_OUT", "PAYMENT", "DEBIT"}:
        new_org = max(0.0, old_org - amount)
    else:
        new_org = old_org + amount

    old_dest = round(rng.uniform(0.0, 3_000_000.0), 2)
    if tx_type in {"TRANSFER", "CASH_OUT", "CASH_IN"}:
        new_dest = old_dest + amount
    else:
        new_dest = old_dest

    prefix = "M" if tx_type == "PAYMENT" and rng.random() < 0.7 else "C"

    return {
        "step": rng.randint(1, 743),
        "type": tx_type,
        "amount": amount,
        "oldbalanceOrg": old_org,
        "newbalanceOrig": round(new_org, 2),
        "oldbalanceDest": old_dest,
        "newbalanceDest": round(new_dest, 2),
        "nameDest": f"{prefix}{rng.randint(100000000, 999999999)}",
    }


def percentile(values: List[float], pct: float) -> float:
    """Compute percentile with linear interpolation."""
    if not values:
        return 0.0
    if len(values) == 1:
        return float(values[0])
    ordered = sorted(values)
    k = (len(ordered) - 1) * pct / 100.0
    lower = int(k)
    upper = min(lower + 1, len(ordered) - 1)
    weight = k - lower
    return float(ordered[lower] * (1 - weight) + ordered[upper] * weight)


def send_request(endpoint: str, randomize_input: bool, timeout: float, index: int, seed: int) -> Dict[str, Any]:
    """Send one request and collect timing/status information."""
    rng = random.Random(seed + index)
    payload = make_transaction(randomize_input, rng)
    started = time.perf_counter()

    try:
        response = requests.post(endpoint, json=payload, timeout=timeout)
        latency_ms = (time.perf_counter() - started) * 1000.0

        try:
            body = response.json()
        except Exception:
            body = {"raw_response": response.text[:500]}

        ok = response.status_code == 200
        return {
            "index": index,
            "ok": ok,
            "status_code": response.status_code,
            "latency_ms": latency_ms,
            "prediction": body.get("prediction"),
            "fraud_probability": body.get("fraud_probability"),
            "error": "" if ok else json.dumps(body, ensure_ascii=False),
        }
    except Exception as exc:
        latency_ms = (time.perf_counter() - started) * 1000.0
        return {
            "index": index,
            "ok": False,
            "status_code": None,
            "latency_ms": latency_ms,
            "prediction": None,
            "fraud_probability": None,
            "error": f"{type(exc).__name__}: {exc}",
        }


def write_csv(rows: List[Dict[str, Any]], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["index", "ok", "status_code", "latency_ms", "prediction", "fraud_probability", "error"]
    with output_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def make_markdown_report(summary: Dict[str, Any]) -> str:
    return f"""# API Benchmark Report

## Configuration

| Metric | Value |
|---|---:|
| API URL | `{summary['api_url']}` |
| Endpoint | `{summary['endpoint']}` |
| Started at | {summary['started_at']} |
| Total requests | {summary['total_requests']} |
| Concurrency | {summary['concurrency']} |
| Timeout | {summary['timeout_seconds']} seconds |
| Randomize input | {summary['randomize_input']} |

## Results

| Metric | Value |
|---|---:|
| Successful requests | {summary['successful_requests']} |
| Failed requests | {summary['failed_requests']} |
| Success rate | {summary['success_rate_pct']:.2f}% |
| Wall time | {summary['wall_time_seconds']:.4f} seconds |
| Throughput | {summary['throughput_rps']:.4f} requests/second |
| Average latency | {summary['avg_latency_ms']:.4f} ms |
| Minimum latency | {summary['min_latency_ms']:.4f} ms |
| Maximum latency | {summary['max_latency_ms']:.4f} ms |
| P50 latency | {summary['p50_latency_ms']:.4f} ms |
| P95 latency | {summary['p95_latency_ms']:.4f} ms |
| P99 latency | {summary['p99_latency_ms']:.4f} ms |

## Interpretation

This benchmark evaluates the deployed model service under concurrent requests. Throughput shows how many prediction requests the system can process per second. Average latency shows the mean response time, while P95 and P99 latency describe tail latency under load. A high success rate and low failed request count indicate stable deployment behavior.
"""


def make_html_report(summary: Dict[str, Any]) -> str:
    rows = [
        ("API URL", f"<code>{html.escape(str(summary['api_url']))}</code>"),
        ("Endpoint", f"<code>{html.escape(str(summary['endpoint']))}</code>"),
        ("Started at", html.escape(str(summary['started_at']))),
        ("Total requests", summary["total_requests"]),
        ("Concurrency", summary["concurrency"]),
        ("Successful requests", summary["successful_requests"]),
        ("Failed requests", summary["failed_requests"]),
        ("Success rate", f"{summary['success_rate_pct']:.2f}%"),
        ("Wall time", f"{summary['wall_time_seconds']:.4f} s"),
        ("Throughput", f"{summary['throughput_rps']:.4f} req/s"),
        ("Average latency", f"{summary['avg_latency_ms']:.4f} ms"),
        ("P50 latency", f"{summary['p50_latency_ms']:.4f} ms"),
        ("P95 latency", f"{summary['p95_latency_ms']:.4f} ms"),
        ("P99 latency", f"{summary['p99_latency_ms']:.4f} ms"),
    ]
    table_rows = "\n".join(f"<tr><td>{name}</td><td>{value}</td></tr>" for name, value in rows)
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>API Benchmark Report</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 40px; color: #1f2937; }}
h1 {{ margin-bottom: 8px; }}
p {{ line-height: 1.6; }}
table {{ border-collapse: collapse; width: 720px; max-width: 100%; margin-top: 20px; }}
th, td {{ border: 1px solid #d1d5db; padding: 10px 12px; text-align: left; }}
th {{ background: #f3f4f6; }}
.card {{ border: 1px solid #e5e7eb; border-radius: 12px; padding: 18px; margin-top: 20px; }}
code {{ background: #f3f4f6; padding: 2px 6px; border-radius: 6px; }}
</style>
</head>
<body>
<h1>API Benchmark Report</h1>
<p>This report summarizes concurrent prediction benchmark results for the deployed fraud detection API.</p>
<table>
<thead><tr><th>Metric</th><th>Value</th></tr></thead>
<tbody>
{table_rows}
</tbody>
</table>
<div class="card">
<h2>Interpretation</h2>
<p>Throughput measures how many prediction requests the system can process per second. Average latency measures mean response time. P95 and P99 latency describe tail latency and are useful for evaluating stability under concurrent load.</p>
</div>
</body>
</html>
"""


def main() -> int:
    parser = argparse.ArgumentParser(description="Benchmark the fraud detection /predict API endpoint.")
    parser.add_argument("--url", default="http://localhost", help="Base API URL, for example http://localhost or http://localhost:8000")
    parser.add_argument("--requests", type=int, default=200, help="Total number of requests to send")
    parser.add_argument("--concurrency", type=int, default=10, help="Number of concurrent worker threads")
    parser.add_argument("--timeout", type=float, default=60.0, help="Timeout per request in seconds")
    parser.add_argument("--randomize-input", action="store_true", help="Generate random valid transaction payloads")
    parser.add_argument("--seed", type=int, default=42, help="Random seed used for reproducible randomized input")
    parser.add_argument("--output-dir", default="benchmark/results", help="Directory for output files")
    args = parser.parse_args()

    if args.requests <= 0:
        raise SystemExit("--requests must be positive")
    if args.concurrency <= 0:
        raise SystemExit("--concurrency must be positive")

    api_url = normalize_url(args.url)
    endpoint = f"{api_url}/predict"
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print("Benchmark configuration")
    print(f"  endpoint:    {endpoint}")
    print(f"  requests:    {args.requests}")
    print(f"  concurrency: {args.concurrency}")
    print(f"  output_dir:  {output_dir}")

    rows: List[Dict[str, Any]] = []
    start_wall = time.perf_counter()

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = [
            executor.submit(send_request, endpoint, args.randomize_input, args.timeout, i + 1, args.seed)
            for i in range(args.requests)
        ]
        for completed, future in enumerate(concurrent.futures.as_completed(futures), start=1):
            rows.append(future.result())
            if completed % max(1, args.requests // 10) == 0 or completed == args.requests:
                print(f"  completed {completed}/{args.requests}")

    wall_time = time.perf_counter() - start_wall
    successful = [row for row in rows if row["ok"]]
    failed = [row for row in rows if not row["ok"]]
    latencies = [float(row["latency_ms"]) for row in successful]

    summary: Dict[str, Any] = {
        "api_url": api_url,
        "endpoint": "/predict",
        "started_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_requests": args.requests,
        "concurrency": args.concurrency,
        "timeout_seconds": args.timeout,
        "randomize_input": bool(args.randomize_input),
        "successful_requests": len(successful),
        "failed_requests": len(failed),
        "success_rate_pct": (len(successful) / args.requests) * 100.0,
        "wall_time_seconds": wall_time,
        "throughput_rps": len(successful) / wall_time if wall_time > 0 else 0.0,
        "avg_latency_ms": statistics.mean(latencies) if latencies else 0.0,
        "min_latency_ms": min(latencies) if latencies else 0.0,
        "max_latency_ms": max(latencies) if latencies else 0.0,
        "p50_latency_ms": percentile(latencies, 50),
        "p95_latency_ms": percentile(latencies, 95),
        "p99_latency_ms": percentile(latencies, 99),
    }

    csv_path = output_dir / "latency_results.csv"
    json_path = output_dir / "benchmark_summary.json"
    md_path = output_dir / "benchmark_report.md"
    html_path = output_dir / "benchmark_report.html"

    write_csv(sorted(rows, key=lambda row: row["index"]), csv_path)
    json_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(make_markdown_report(summary), encoding="utf-8")
    html_path.write_text(make_html_report(summary), encoding="utf-8")

    print("\nBenchmark summary")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("\nOutput files")
    print(f"  {csv_path}")
    print(f"  {json_path}")
    print(f"  {md_path}")
    print(f"  {html_path}")

    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
