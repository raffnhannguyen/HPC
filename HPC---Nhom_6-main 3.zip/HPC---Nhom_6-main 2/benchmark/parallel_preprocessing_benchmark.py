#!/usr/bin/env python3
"""
Parallel preprocessing benchmark for the fraud detection HPC project.

This script compares sequential and parallel data preparation time.
It supports two input formats:

1. Raw PaySim-style data:
   step, type, amount, nameOrig, oldbalanceOrg, newbalanceOrig,
   nameDest, oldbalanceDest, newbalanceDest, isFraud, isFlaggedFraud

   The script will run feature engineering similar to the API/preprocessing pipeline:
   isMerchant, day, errorBalanceOrig, errorBalanceDest,
   isOrigBalanceZeroAfter, one-hot encoding for transaction type.

2. Processed model-ready data:
   the feature columns stored in model/saved_models/feature_names.pkl,
   optionally with isFraud.

   The script will benchmark model feature preparation: dropping label,
   selecting/reordering feature columns and casting to float32.

Outputs:
- benchmark/results/parallel_preprocessing_summary.json
- benchmark/results/parallel_preprocessing_report.md
- benchmark/results/parallel_preprocessing_sample.csv
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List, Tuple

import joblib
import numpy as np
import pandas as pd


TYPE_COLUMNS = [
    "type_CASH_IN",
    "type_CASH_OUT",
    "type_DEBIT",
    "type_PAYMENT",
    "type_TRANSFER",
]

RAW_REQUIRED_COLUMNS = {
    "step",
    "type",
    "amount",
    "oldbalanceOrg",
    "newbalanceOrig",
    "oldbalanceDest",
    "newbalanceDest",
    "nameDest",
}


@dataclass
class BenchmarkResult:
    input_path: str
    detected_mode: str
    rows_processed: int
    columns_output: int
    workers: int
    chunks: int
    sample_size: int | None
    sequential_time_seconds: float
    parallel_time_seconds: float
    speedup: float
    efficiency_pct: float
    output_dir: str


def load_model_metadata(model_dir: Path) -> Tuple[List[str], List[str]]:
    feature_path = model_dir / "feature_names.pkl"
    numeric_path = model_dir / "numeric_cols.pkl"

    if not feature_path.exists():
        raise FileNotFoundError(f"feature_names.pkl not found at {feature_path}")
    if not numeric_path.exists():
        raise FileNotFoundError(f"numeric_cols.pkl not found at {numeric_path}")

    feature_names = list(joblib.load(feature_path))
    numeric_cols = list(joblib.load(numeric_path))
    return feature_names, numeric_cols


def detect_mode(df: pd.DataFrame, feature_names: List[str], requested_mode: str) -> str:
    if requested_mode != "auto":
        return requested_mode

    columns = set(df.columns)
    if RAW_REQUIRED_COLUMNS.issubset(columns) and "type" in columns:
        return "raw"

    if set(feature_names).issubset(columns):
        return "processed"

    missing_raw = sorted(RAW_REQUIRED_COLUMNS - columns)
    missing_processed = sorted(set(feature_names) - columns)
    raise ValueError(
        "Unable to detect input mode. "
        f"Missing raw columns: {missing_raw}. "
        f"Missing processed feature columns: {missing_processed}."
    )


def preprocess_raw_chunk(chunk: pd.DataFrame, feature_names: List[str], numeric_cols: List[str], model_dir: str) -> pd.DataFrame:
    """Feature engineering for raw PaySim-style data."""
    df = chunk.copy()

    df["isMerchant"] = df["nameDest"].astype(str).str.startswith("M").astype(int)
    df["day"] = (df["step"] // 24).astype(int)
    df["errorBalanceOrig"] = df["oldbalanceOrg"] - df["amount"] - df["newbalanceOrig"]
    df["errorBalanceDest"] = df["oldbalanceDest"] + df["amount"] - df["newbalanceDest"]
    df["isOrigBalanceZeroAfter"] = (df["newbalanceOrig"] == 0).astype(int)

    dummies = pd.get_dummies(df["type"], prefix="type")
    df = pd.concat([df, dummies], axis=1)

    for col in TYPE_COLUMNS:
        if col not in df.columns:
            df[col] = 0

    for col in feature_names:
        if col not in df.columns:
            df[col] = 0

    X = df[feature_names].copy()

    # Optional scaling to match the model pipeline if scaler.pkl is available.
    # The scaler is loaded inside each process to avoid pickling issues.
    scaler_path = Path(model_dir) / "scaler.pkl"
    if scaler_path.exists() and numeric_cols:
        scaler = joblib.load(scaler_path)
        X.loc[:, numeric_cols] = scaler.transform(X[numeric_cols].astype("float32"))

    return X.astype("float32")


def preprocess_processed_chunk(chunk: pd.DataFrame, feature_names: List[str], numeric_cols: List[str], model_dir: str) -> pd.DataFrame:
    """Model-ready data preparation for already processed data."""
    df = chunk.copy()
    for col in feature_names:
        if col not in df.columns:
            df[col] = 0
    X = df[feature_names].astype("float32")
    return X


def run_sequential(df: pd.DataFrame, mode: str, feature_names: List[str], numeric_cols: List[str], model_dir: Path) -> Tuple[pd.DataFrame, float]:
    started = time.perf_counter()
    if mode == "raw":
        out = preprocess_raw_chunk(df, feature_names, numeric_cols, str(model_dir))
    elif mode == "processed":
        out = preprocess_processed_chunk(df, feature_names, numeric_cols, str(model_dir))
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    elapsed = time.perf_counter() - started
    return out, elapsed


def split_dataframe(df: pd.DataFrame, chunks: int) -> List[pd.DataFrame]:
    if chunks <= 1:
        return [df]
    return [part for part in np.array_split(df, chunks) if len(part) > 0]


def run_parallel(df: pd.DataFrame, mode: str, feature_names: List[str], numeric_cols: List[str], model_dir: Path, workers: int, chunks: int) -> Tuple[pd.DataFrame, float]:
    parts = split_dataframe(df, chunks)
    started = time.perf_counter()

    worker_fn = preprocess_raw_chunk if mode == "raw" else preprocess_processed_chunk

    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [
            executor.submit(worker_fn, part, feature_names, numeric_cols, str(model_dir))
            for part in parts
        ]
        outputs = [future.result() for future in futures]

    out = pd.concat(outputs, axis=0).sort_index()
    elapsed = time.perf_counter() - started
    return out, elapsed


def validate_outputs(seq: pd.DataFrame, par: pd.DataFrame) -> None:
    if seq.shape != par.shape:
        raise AssertionError(f"Output shape mismatch: sequential={seq.shape}, parallel={par.shape}")

    if list(seq.columns) != list(par.columns):
        raise AssertionError("Output columns mismatch between sequential and parallel outputs")

    # Floating point differences may appear after scaling; tolerate very small differences.
    if not np.allclose(seq.values, par.values, rtol=1e-5, atol=1e-6, equal_nan=True):
        diff = np.nanmax(np.abs(seq.values - par.values))
        raise AssertionError(f"Sequential and parallel outputs are not equivalent. max_abs_diff={diff}")


def write_report(result: BenchmarkResult) -> None:
    output_dir = Path(result.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    summary_path = output_dir / "parallel_preprocessing_summary.json"
    report_path = output_dir / "parallel_preprocessing_report.md"

    with summary_path.open("w", encoding="utf-8") as f:
        json.dump(asdict(result), f, ensure_ascii=False, indent=2)

    report = f"""# Parallel Preprocessing Benchmark Report

## Configuration

| Item | Value |
|---|---:|
| Input path | `{result.input_path}` |
| Detected mode | `{result.detected_mode}` |
| Rows processed | {result.rows_processed:,} |
| Output columns | {result.columns_output} |
| Workers | {result.workers} |
| Chunks | {result.chunks} |
| Sample size | {result.sample_size if result.sample_size is not None else 'Full input'} |

## Result

| Metric | Value |
|---|---:|
| Sequential time | {result.sequential_time_seconds:.6f} seconds |
| Parallel time | {result.parallel_time_seconds:.6f} seconds |
| Speedup | {result.speedup:.4f}x |
| Efficiency | {result.efficiency_pct:.2f}% |

## Interpretation

Speedup is calculated as sequential time divided by parallel time. Efficiency is calculated as speedup divided by number of workers. If the input file is already processed, this benchmark measures parallel feature preparation. If the input file is raw PaySim-style data, this benchmark measures feature engineering and model-ready transformation.

A speedup greater than 1 indicates that parallel processing is faster than sequential processing. If speedup is less than 1, the overhead of multiprocessing is larger than the benefit for the tested data size. This can happen when the dataset is small or when the preprocessing operations are already highly optimized by pandas.
"""

    with report_path.open("w", encoding="utf-8") as f:
        f.write(report)

    print("\nOutput files")
    print(f"  {summary_path}")
    print(f"  {report_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Sequential vs parallel preprocessing benchmark")
    parser.add_argument("--input", default="data/processed/test.csv", help="Input CSV path")
    parser.add_argument("--model-dir", default="model/saved_models", help="Directory containing feature_names.pkl, numeric_cols.pkl and optional scaler.pkl")
    parser.add_argument("--mode", choices=["auto", "raw", "processed"], default="auto", help="Input mode")
    parser.add_argument("--sample-size", type=int, default=200000, help="Number of rows to sample. Use 0 for full input")
    parser.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1), help="Number of parallel workers")
    parser.add_argument("--chunks", type=int, default=0, help="Number of chunks. Default: workers * 2")
    parser.add_argument("--output-dir", default="benchmark/results", help="Output directory")
    parser.add_argument("--random-state", type=int, default=42, help="Random state for sampling")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    input_path = Path(args.input)
    model_dir = Path(args.model_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    feature_names, numeric_cols = load_model_metadata(model_dir)

    print("Parallel preprocessing benchmark")
    print(f"  input:      {input_path}")
    print(f"  model_dir:  {model_dir}")
    print(f"  workers:    {args.workers}")

    df = pd.read_csv(input_path)
    total_rows = len(df)

    sample_size = None if args.sample_size == 0 else min(args.sample_size, total_rows)
    if sample_size is not None and sample_size < total_rows:
        df = df.sample(n=sample_size, random_state=args.random_state).sort_index()

    mode = detect_mode(df, feature_names, args.mode)
    chunks = args.chunks if args.chunks and args.chunks > 0 else max(args.workers * 2, 1)

    print(f"  total rows: {total_rows:,}")
    print(f"  used rows:  {len(df):,}")
    print(f"  mode:       {mode}")
    print(f"  chunks:     {chunks}")

    seq_out, seq_time = run_sequential(df, mode, feature_names, numeric_cols, model_dir)
    par_out, par_time = run_parallel(df, mode, feature_names, numeric_cols, model_dir, args.workers, chunks)

    validate_outputs(seq_out, par_out)

    sample_path = output_dir / "parallel_preprocessing_sample.csv"
    par_out.head(20).to_csv(sample_path, index=False)

    speedup = seq_time / par_time if par_time > 0 else math.inf
    efficiency = (speedup / args.workers * 100) if args.workers > 0 and math.isfinite(speedup) else 0.0

    result = BenchmarkResult(
        input_path=str(input_path),
        detected_mode=mode,
        rows_processed=len(df),
        columns_output=seq_out.shape[1],
        workers=args.workers,
        chunks=chunks,
        sample_size=sample_size,
        sequential_time_seconds=seq_time,
        parallel_time_seconds=par_time,
        speedup=speedup,
        efficiency_pct=efficiency,
        output_dir=str(output_dir),
    )

    print("\nBenchmark summary")
    print(json.dumps(asdict(result), ensure_ascii=False, indent=2))
    print(f"\nSample output file\n  {sample_path}")
    write_report(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
